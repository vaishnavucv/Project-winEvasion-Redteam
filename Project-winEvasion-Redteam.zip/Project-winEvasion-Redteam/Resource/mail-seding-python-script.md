## 1. Python Script for Sending Mail with Payload.exe

a. We use a Python script to automatically send emails, simulating real-world email sending delays and purposes.

b. The mail script is available on our [GitHub profile](https://github.com/vaishnavucv/Project-winEvasion-Redteam/tree/main/Project-Files/mail-server).

c. The Python script has a pre-designed email template that includes different attachments according to the scenario.

d. **Important:** Ensure the mail Docker server is running before using the mail-sending Python script.

e. To start the Docker mail server, we have created a bash script that will start the mail server with error handling: `./mail-start.sh`.
